package com.example.qrhunterapp_t11.interfaces;

/**
 * Callback for querying the database
 *
 * @author Afra
 */
public interface QueryCallback {
    void queryCompleteCheck(boolean queryComplete);
}
